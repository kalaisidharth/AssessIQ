from fastapi import APIRouter, HTTPException, Header
from core.database import get_db
from core.security import verify_password, get_password_hash, create_access_token
from core.config import settings
from models.schemas import UserRegister, UserLogin
from datetime import datetime
from typing import Optional

router = APIRouter()

def serialize_user(user: dict) -> dict:
    return {
        "id": str(user["_id"]),
        "name": user["name"],
        "email": user["email"],
        "role": user["role"],
        "created_at": str(user.get("created_at", "")),
    }

@router.post("/register", status_code=201)
async def register(data: UserRegister):
    db = get_db()
    existing = await db.users.find_one({"email": data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_doc = {
        "name": data.name,
        "email": data.email,
        "password": get_password_hash(data.password),
        "role": "user",
        "created_at": datetime.utcnow(),
        "assigned_assessments": [],
    }
    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id
    token = create_access_token({"sub": str(result.inserted_id)})
    return {"access_token": token, "token_type": "bearer", "user": serialize_user(user_doc)}

@router.post("/login")
async def login(data: UserLogin):
    db = get_db()
    user = await db.users.find_one({"email": data.email})
    if not user or not verify_password(data.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({"sub": str(user["_id"])})
    return {"access_token": token, "token_type": "bearer", "user": serialize_user(user)}

@router.post("/admin/register", status_code=201)
async def register_admin(
    data: UserRegister,
    x_admin_key: Optional[str] = Header(None),
):
    """Admin registration — requires X-Admin-Key header matching ADMIN_SECRET_KEY in .env"""
    if not x_admin_key or x_admin_key != settings.ADMIN_SECRET_KEY:
        raise HTTPException(status_code=403, detail="Invalid or missing admin secret key")

    db = get_db()
    existing = await db.users.find_one({"email": data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_doc = {
        "name": data.name,
        "email": data.email,
        "password": get_password_hash(data.password),
        "role": "admin",
        "created_at": datetime.utcnow(),
        "assigned_assessments": [],
    }
    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id
    token = create_access_token({"sub": str(result.inserted_id)})
    return {"access_token": token, "token_type": "bearer", "user": serialize_user(user_doc)}