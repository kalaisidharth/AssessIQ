from fastapi import APIRouter, HTTPException, Depends
from core.database import get_db
from core.security import get_current_admin
from models.schemas import AssessmentConfig, AdminSetMin
from services.ai_service import generate_assessment_rounds
from bson import ObjectId
from datetime import datetime
from typing import List

router = APIRouter()

def oid(id_str: str):
    try:
        return ObjectId(id_str)
    except:
        raise HTTPException(status_code=400, detail="Invalid ID format")

def serialize(doc):
    if doc is None:
        return None
    doc["id"] = str(doc.pop("_id"))
    return doc

@router.get("/users")
async def get_all_users(admin=Depends(get_current_admin)):
    db = get_db()
    users = await db.users.find({"role": "user"}).to_list(1000)
    return [{"id": str(u["_id"]), "name": u["name"], "email": u["email"], 
             "created_at": str(u.get("created_at", ""))} for u in users]

@router.get("/users/{user_id}/results")
async def get_user_results(user_id: str, admin=Depends(get_current_admin)):
    db = get_db()
    results = await db.assessment_results.find({"user_id": user_id}).to_list(100)
    output = []
    for r in results:
        assessment = await db.assessments.find_one({"_id": oid(r["assessment_id"])})
        r["id"] = str(r.pop("_id"))
        r["assessment_title"] = assessment["title"] if assessment else "Unknown"
        output.append(r)
    return output

@router.post("/assessments", status_code=201)
async def create_assessment(data: AssessmentConfig, admin=Depends(get_current_admin)):
    db = get_db()

    # Generate AI questions for each round
    rounds_data = [r.dict() for r in data.rounds]
    generated_questions = await generate_assessment_rounds(rounds_data)

    # MongoDB requires string keys — convert int round numbers to strings
    questions_str_keys = {str(k): v for k, v in generated_questions.items()}

    assessment_doc = {
        "title": data.title,
        "description": data.description,
        "rounds": rounds_data,
        "questions": questions_str_keys,
        "assigned_to": data.assigned_to,
        "allow_retake": data.allow_retake,
        "created_by": str(admin["_id"]),
        "created_at": datetime.utcnow(),
    }

    result = await db.assessments.insert_one(assessment_doc)

    # Assign to users
    if data.assigned_to:
        await db.users.update_many(
            {"_id": {"$in": [oid(uid) for uid in data.assigned_to]}},
            {"$addToSet": {"assigned_assessments": str(result.inserted_id)}}
        )

    return {"id": str(result.inserted_id), "message": "Assessment created and questions generated"}

@router.get("/assessments")
async def get_assessments(admin=Depends(get_current_admin)):
    db = get_db()
    assessments = await db.assessments.find({}).to_list(100)
    output = []
    for a in assessments:
        a["id"] = str(a.pop("_id"))
        a.pop("questions", None)  # Don't send questions in list view
        output.append(a)
    return output

@router.get("/assessments/{assessment_id}")
async def get_assessment(assessment_id: str, admin=Depends(get_current_admin)):
    db = get_db()
    a = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not a:
        raise HTTPException(status_code=404, detail="Assessment not found")
    a["id"] = str(a.pop("_id"))
    return a

@router.put("/assessments/{assessment_id}/assign")
async def assign_assessment(assessment_id: str, user_ids: List[str], admin=Depends(get_current_admin)):
    db = get_db()
    assessment = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    # Update assessment assigned list
    await db.assessments.update_one(
        {"_id": oid(assessment_id)},
        {"$addToSet": {"assigned_to": {"$each": user_ids}}}
    )

    # Assign to users
    await db.users.update_many(
        {"_id": {"$in": [oid(uid) for uid in user_ids]}},
        {"$addToSet": {"assigned_assessments": assessment_id}}
    )
    return {"message": f"Assessment assigned to {len(user_ids)} users"}

@router.put("/assessments/{assessment_id}/min-scores")
async def update_min_scores(assessment_id: str, data: AdminSetMin, admin=Depends(get_current_admin)):
    db = get_db()
    assessment = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    rounds = assessment["rounds"]
    for round_cfg in rounds:
        rn = round_cfg["round_number"]
        if rn in data.rounds_min_scores:
            round_cfg["min_score_percent"] = data.rounds_min_scores[rn]

    await db.assessments.update_one(
        {"_id": oid(assessment_id)},
        {"$set": {"rounds": rounds}}
    )
    return {"message": "Minimum scores updated"}

@router.delete("/assessments/{assessment_id}")
async def delete_assessment(assessment_id: str, admin=Depends(get_current_admin)):
    db = get_db()
    await db.assessments.delete_one({"_id": oid(assessment_id)})
    return {"message": "Assessment deleted"}

@router.get("/results")
async def get_all_results(admin=Depends(get_current_admin)):
    db = get_db()
    results = await db.assessment_results.find({}).to_list(500)
    output = []
    for r in results:
        user = await db.users.find_one({"_id": oid(r["user_id"])})
        assessment = await db.assessments.find_one({"_id": oid(r["assessment_id"])})
        output.append({
            "id": str(r["_id"]),
            "user_name": user["name"] if user else "Unknown",
            "user_email": user["email"] if user else "",
            "assessment_title": assessment["title"] if assessment else "Unknown",
            "overall_score": r.get("overall_score", 0),
            "status": r.get("status", "in_progress"),
            "completed_at": str(r.get("completed_at", "")),
            "rounds_completed": len(r.get("round_results", [])),
            "failed_at_round": r.get("failed_at_round"),
        })
    return output

@router.post("/regenerate-questions/{assessment_id}")
async def regenerate_questions(assessment_id: str, admin=Depends(get_current_admin)):
    db = get_db()
    assessment = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    generated_questions = await generate_assessment_rounds(assessment["rounds"])
    await db.assessments.update_one(
        {"_id": oid(assessment_id)},
        {"$set": {"questions": {str(k): v for k, v in generated_questions.items()}}}
    )
    return {"message": "Questions regenerated successfully"}