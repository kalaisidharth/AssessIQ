from fastapi import APIRouter, HTTPException, Depends
from core.database import get_db
from core.security import get_current_user
from bson import ObjectId

router = APIRouter()

def oid(id_str: str):
    try:
        return ObjectId(id_str)
    except:
        raise HTTPException(status_code=400, detail="Invalid ID")

@router.get("/me")
async def get_profile(current_user=Depends(get_current_user)):
    return {
        "id": str(current_user["_id"]),
        "name": current_user["name"],
        "email": current_user["email"],
        "role": current_user["role"],
    }

@router.get("/assessments")
async def get_my_assessments(current_user=Depends(get_current_user)):
    db = get_db()
    assigned_ids = current_user.get("assigned_assessments", [])
    user_id = str(current_user["_id"])

    assessments = []
    for aid in assigned_ids:
        try:
            a = await db.assessments.find_one({"_id": oid(aid)})
            if not a:
                continue

            # Check if user has a result
            result = await db.assessment_results.find_one({
                "user_id": user_id,
                "assessment_id": aid
            })

            status = "not_started"
            if result:
                status = result.get("status", "in_progress")

            assessments.append({
                "id": str(a["_id"]),
                "title": a["title"],
                "description": a.get("description", ""),
                "num_rounds": len(a["rounds"]),
                "rounds": [{"round_number": r["round_number"], "name": r["name"],
                            "topic": r["topic"], "num_questions": r["num_questions"],
                            "time_limit_minutes": r["time_limit_minutes"]} for r in a["rounds"]],
                "status": status,
                "allow_retake": a.get("allow_retake", False),
                "result_id": str(result["_id"]) if result else None,
            })
        except:
            continue

    return assessments

@router.get("/results")
async def get_my_results(current_user=Depends(get_current_user)):
    db = get_db()
    user_id = str(current_user["_id"])
    results = await db.assessment_results.find({"user_id": user_id}).to_list(100)
    output = []
    for r in results:
        assessment = await db.assessments.find_one({"_id": oid(r["assessment_id"])})
        output.append({
            "id": str(r["_id"]),
            "assessment_id": r["assessment_id"],
            "assessment_title": assessment["title"] if assessment else "Unknown",
            "overall_score": r.get("overall_score", 0),
            "status": r.get("status", "in_progress"),
            "round_results": r.get("round_results", []),
            "failed_at_round": r.get("failed_at_round"),
            "completed_at": str(r.get("completed_at", "")),
            "started_at": str(r.get("started_at", "")),
        })
    return output

@router.get("/results/{result_id}")
async def get_result_detail(result_id: str, current_user=Depends(get_current_user)):
    db = get_db()
    result = await db.assessment_results.find_one({
        "_id": oid(result_id),
        "user_id": str(current_user["_id"])
    })
    if not result:
        raise HTTPException(status_code=404, detail="Result not found")
    assessment = await db.assessments.find_one({"_id": oid(result["assessment_id"])})
    result["id"] = str(result.pop("_id"))
    result["assessment_title"] = assessment["title"] if assessment else "Unknown"
    return result

@router.get("/dashboard")
async def get_dashboard(current_user=Depends(get_current_user)):
    db = get_db()
    user_id = str(current_user["_id"])

    results = await db.assessment_results.find({"user_id": user_id}).to_list(100)
    assigned_count = len(current_user.get("assigned_assessments", []))
    completed = [r for r in results if r.get("status") == "completed"]
    failed = [r for r in results if r.get("status") == "failed"]

    avg_score = 0
    if completed:
        avg_score = sum(r.get("overall_score", 0) for r in completed) / len(completed)

    return {
        "total_assigned": assigned_count,
        "completed": len(completed),
        "failed": len(failed),
        "in_progress": len([r for r in results if r.get("status") == "in_progress"]),
        "average_score": round(avg_score, 1),
        "recent_results": sorted(
            [{"id": str(r["_id"]), "assessment_id": r["assessment_id"],
              "status": r.get("status"), "overall_score": r.get("overall_score", 0),
              "completed_at": str(r.get("completed_at", ""))} for r in results],
            key=lambda x: x["completed_at"], reverse=True
        )[:5]
    }
