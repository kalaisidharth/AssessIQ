from fastapi import APIRouter, HTTPException, Depends
from core.database import get_db
from core.security import get_current_user
from models.schemas import AssessmentSubmission
from bson import ObjectId
from datetime import datetime
from typing import List, Dict

router = APIRouter()

def oid(id_str: str):
    try:
        return ObjectId(id_str)
    except:
        raise HTTPException(status_code=400, detail="Invalid ID")

@router.get("/{assessment_id}/start")
async def start_or_resume_assessment(assessment_id: str, current_user=Depends(get_current_user)):
    db = get_db()
    user_id = str(current_user["_id"])

    assessment = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    # Check if user is assigned
    if user_id not in assessment.get("assigned_to", []):
        raise HTTPException(status_code=403, detail="You are not assigned to this assessment")

    # Check existing result
    existing_result = await db.assessment_results.find_one({
        "user_id": user_id,
        "assessment_id": assessment_id
    })

    if existing_result:
        status = existing_result.get("status")
        if status in ["completed", "failed"] and not assessment.get("allow_retake"):
            raise HTTPException(status_code=400, detail="Assessment already completed. Retake not allowed.")
        if status in ["completed", "failed"] and assessment.get("allow_retake"):
            # Delete old result to allow retake
            await db.assessment_results.delete_one({"_id": existing_result["_id"]})
        elif status == "in_progress":
            # Resume - return current round info
            current_round = existing_result.get("current_round", 1)
            return {
                "result_id": str(existing_result["_id"]),
                "current_round": current_round,
                "assessment": _serialize_assessment_for_user(assessment),
                "resumed": True
            }

    # Create new result
    result_doc = {
        "user_id": user_id,
        "assessment_id": assessment_id,
        "status": "in_progress",
        "current_round": 1,
        "round_results": [],
        "overall_score": 0,
        "started_at": datetime.utcnow(),
    }
    result = await db.assessment_results.insert_one(result_doc)

    return {
        "result_id": str(result.inserted_id),
        "current_round": 1,
        "assessment": _serialize_assessment_for_user(assessment),
        "resumed": False
    }

@router.get("/{assessment_id}/round/{round_number}/questions")
async def get_round_questions(assessment_id: str, round_number: int, current_user=Depends(get_current_user)):
    db = get_db()
    user_id = str(current_user["_id"])

    assessment = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    # Verify user has active result in this round
    result = await db.assessment_results.find_one({
        "user_id": user_id,
        "assessment_id": assessment_id,
        "status": "in_progress"
    })
    if not result:
        raise HTTPException(status_code=400, detail="No active assessment session")

    if result.get("current_round") != round_number:
        raise HTTPException(status_code=400, detail=f"Not on round {round_number}")

    # Get questions for this round (hide correct answers from user)
    questions_map = assessment.get("questions", {})
    raw_questions = questions_map.get(round_number) or questions_map.get(str(round_number), [])

    if not raw_questions:
        raise HTTPException(status_code=404, detail="Questions not found for this round")

    # Strip correct answers before sending to user
    questions_for_user = []
    for q in raw_questions:
        questions_for_user.append({
            "id": q["id"],
            "question": q["question"],
            "options": q["options"],
        })

    # Get round config
    round_config = next((r for r in assessment["rounds"] if r["round_number"] == round_number), None)

    return {
        "round_number": round_number,
        "round_name": round_config["name"] if round_config else f"Round {round_number}",
        "topic": round_config["topic"] if round_config else "",
        "time_limit_minutes": round_config["time_limit_minutes"] if round_config else 15,
        "min_score_percent": round_config["min_score_percent"] if round_config else 60,
        "questions": questions_for_user,
        "total_questions": len(questions_for_user),
    }

@router.post("/{assessment_id}/round/{round_number}/submit")
async def submit_round(assessment_id: str, round_number: int, data: AssessmentSubmission, current_user=Depends(get_current_user)):
    db = get_db()
    user_id = str(current_user["_id"])

    assessment = await db.assessments.find_one({"_id": oid(assessment_id)})
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    result = await db.assessment_results.find_one({
        "user_id": user_id,
        "assessment_id": assessment_id,
        "status": "in_progress"
    })
    if not result:
        raise HTTPException(status_code=400, detail="No active assessment session")

    # Get correct answers
    questions_map = assessment.get("questions", {})
    raw_questions = questions_map.get(round_number) or questions_map.get(str(round_number), [])
    correct_map = {q["id"]: {"correct": q["correct_answer"], "explanation": q.get("explanation", "")} for q in raw_questions}

    # Score the submission
    answered = {a["question_id"]: a["selected_option"] for a in data.answers}
    detailed_answers = []
    correct_count = 0

    for q in raw_questions:
        qid = q["id"]
        selected = answered.get(qid, "")
        correct = correct_map[qid]["correct"]
        is_correct = selected == correct
        if is_correct:
            correct_count += 1

        detailed_answers.append({
            "question_id": qid,
            "question": q["question"],
            "options": q["options"],
            "selected_option": selected,
            "correct_option": correct,
            "is_correct": is_correct,
            "explanation": correct_map[qid]["explanation"]
        })

    total_q = len(raw_questions)
    percent = round((correct_count / total_q) * 100, 1) if total_q > 0 else 0

    # Get min score for this round
    round_config = next((r for r in assessment["rounds"] if r["round_number"] == round_number), None)
    min_score = round_config["min_score_percent"] if round_config else 60

    passed = percent >= min_score
    is_last_round = round_number == len(assessment["rounds"])

    round_result = {
        "round_number": round_number,
        "round_name": round_config["name"] if round_config else f"Round {round_number}",
        "score": correct_count,
        "total": total_q,
        "percent": percent,
        "passed": passed,
        "min_score_percent": min_score,
        "time_taken_seconds": data.time_taken_seconds,
        "answers": detailed_answers,
    }

    # Update result document
    update_fields = {"$push": {"round_results": round_result}}

    if not passed:
        # Failed this round - exit assessment
        update_fields["$set"] = {
            "status": "failed",
            "failed_at_round": round_number,
            "overall_score": percent,
            "completed_at": datetime.utcnow(),
        }
    elif is_last_round:
        # Passed all rounds - completed!
        all_scores = [rr.get("percent", 0) for rr in result.get("round_results", [])]
        all_scores.append(percent)
        overall = round(sum(all_scores) / len(all_scores), 1)
        update_fields["$set"] = {
            "status": "completed",
            "overall_score": overall,
            "completed_at": datetime.utcnow(),
        }
    else:
        # Passed, move to next round
        update_fields["$set"] = {"current_round": round_number + 1}

    await db.assessment_results.update_one({"_id": result["_id"]}, update_fields)

    return {
        "round_number": round_number,
        "score": correct_count,
        "total": total_q,
        "percent": percent,
        "passed": passed,
        "min_score_percent": min_score,
        "answers": detailed_answers,
        "next_round": round_number + 1 if passed and not is_last_round else None,
        "assessment_status": "failed" if not passed else ("completed" if is_last_round else "in_progress"),
        "failed_at_round": round_number if not passed else None,
        "message": (
            f"❌ You scored {percent}% which is below the minimum {min_score}%. Assessment ended."
            if not passed else
            f"✅ Round {round_number} passed! Score: {percent}%"
        )
    }

def _serialize_assessment_for_user(assessment: dict) -> dict:
    return {
        "id": str(assessment["_id"]),
        "title": assessment["title"],
        "description": assessment.get("description", ""),
        "num_rounds": len(assessment["rounds"]),
        "rounds": [
            {
                "round_number": r["round_number"],
                "name": r["name"],
                "topic": r["topic"],
                "num_questions": r["num_questions"],
                "time_limit_minutes": r["time_limit_minutes"],
                "min_score_percent": r["min_score_percent"],
            }
            for r in assessment["rounds"]
        ]
    }
