import json
import re
from core.config import settings
from typing import List, Dict
from huggingface_hub import InferenceClient

DIFFICULTY_MAP = {
    "easy": "basic, foundational",
    "medium": "intermediate, practical",
    "hard": "advanced, expert-level"
}


def _get_client() -> InferenceClient:
    key = settings.HF_API_KEY.strip()
    if not key:
        raise ValueError("HF_API_KEY is empty! Add it to backend/.env")
    return InferenceClient(
        model="meta-llama/Meta-Llama-3-8B-Instruct",
        token=key,
    )


def _clean_and_parse_json(raw_text: str, num_questions: int) -> List[Dict]:
    """Robustly extract and parse JSON from model output."""

    # Strip markdown fences
    raw_text = re.sub(r"```json\s*", "", raw_text)
    raw_text = re.sub(r"```\s*", "", raw_text)
    raw_text = raw_text.strip()

    # Try 1: find complete JSON array
    json_match = re.search(r'\[\s*\{[\s\S]*\}\s*\]', raw_text)
    if json_match:
        try:
            return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass

    # Try 2: extract individual question objects and rebuild array
    # This handles truncated or slightly malformed JSON
    question_pattern = re.finditer(r'\{[^{}]*"question"[^{}]*"options"[\s\S]*?"correct_answer"[^{}]*\}', raw_text)
    questions = []
    for match in question_pattern:
        try:
            q = json.loads(match.group())
            questions.append(q)
        except json.JSONDecodeError:
            continue

    if questions:
        return questions

    # Try 3: fix common JSON issues and retry
    fixed = raw_text

    # Fix single quotes to double quotes
    fixed = re.sub(r"(?<![\\])'", '"', fixed)

    # Fix trailing commas before ] or }
    fixed = re.sub(r',\s*([\]}])', r'\1', fixed)

    # Fix missing commas between objects
    fixed = re.sub(r'}\s*\n\s*{', '},{', fixed)

    json_match = re.search(r'\[\s*\{[\s\S]*\}\s*\]', fixed)
    if json_match:
        try:
            return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass

    # Try 4: truncate at last valid complete question object
    last_valid = raw_text.rfind('},')
    if last_valid == -1:
        last_valid = raw_text.rfind('}')
    if last_valid > 0:
        truncated = raw_text[:last_valid + 1]
        # Find the opening bracket
        start = truncated.find('[')
        if start >= 0:
            attempt = truncated[start:] + ']'
            try:
                return json.loads(attempt)
            except json.JSONDecodeError:
                pass

    raise ValueError(f"Could not parse JSON from model response. Raw text:\n{raw_text[:500]}")


async def generate_questions(
    topic: str,
    difficulty: str,
    num_questions: int,
    round_number: int,
    round_name: str,
) -> List[Dict]:
    difficulty_desc = DIFFICULTY_MAP.get(difficulty, "intermediate")
    client = _get_client()

    messages = [
        {
            "role": "system",
            "content": (
                "You are an expert technical interviewer. "
                "You respond ONLY with valid JSON arrays. "
                "Never include markdown, code fences, or any text outside the JSON array. "
                "Always ensure the JSON is complete and valid."
            )
        },
        {
            "role": "user",
            "content": f"""Generate exactly {num_questions} multiple choice questions for a {round_name} (Round {round_number}) interview assessment.

Topic: {topic}
Difficulty: {difficulty_desc}

Rules:
- Each question must test real knowledge clearly
- Exactly 4 options labeled A, B, C, D
- Only ONE correct answer
- Include short code snippets for technical topics where helpful
- Wrong options must be plausible

Return ONLY this JSON array, no other text:
[
  {{
    "id": "q1",
    "question": "Question text?",
    "options": {{
      "A": "First option",
      "B": "Second option",
      "C": "Third option",
      "D": "Fourth option"
    }},
    "correct_answer": "A",
    "explanation": "One sentence explaining why A is correct."
  }}
]

Generate exactly {num_questions} questions on "{topic}" at {difficulty_desc} difficulty. Output ONLY the JSON array:"""
        }
    ]

    response = client.chat_completion(
        messages=messages,
        max_tokens=4096,
        temperature=0.4,
    )

    raw_text = response.choices[0].message["content"].strip()

    questions = _clean_and_parse_json(raw_text, num_questions)

    # Validate and assign unique IDs
    validated = []
    for i, q in enumerate(questions):
        q["id"] = f"r{round_number}_q{i + 1}"
        if "options" not in q:
            continue  # skip malformed questions
        if "correct_answer" not in q:
            continue
        if "explanation" not in q:
            q["explanation"] = ""
        validated.append(q)

    if not validated:
        raise ValueError(f"No valid questions could be parsed for topic: {topic}")

    return validated[:num_questions]


async def generate_assessment_rounds(rounds_config: list) -> Dict:
    all_rounds = {}
    for round_cfg in rounds_config:
        questions = await generate_questions(
            topic=round_cfg["topic"],
            difficulty=round_cfg.get("difficulty", "medium"),
            num_questions=round_cfg.get("num_questions", 5),
            round_number=round_cfg["round_number"],
            round_name=round_cfg["name"],
        )
        all_rounds[round_cfg["round_number"]] = questions
    return all_rounds