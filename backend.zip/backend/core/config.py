from pydantic_settings import BaseSettings
from pathlib import Path

ENV_PATH = Path(__file__).parent.parent / ".env"

class Settings(BaseSettings):
    MONGODB_URL: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "interview_assessment"
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24
    HF_API_KEY: str = ""
    ADMIN_SECRET_KEY: str = "changeme-set-this-in-env"

    class Config:
        env_file = str(ENV_PATH)
        env_file_encoding = "utf-8"

settings = Settings()

print(f"🔑 HF_API_KEY loaded: {'YES ✅' if settings.HF_API_KEY else 'NO ❌ — check your .env file'}")
print(f"📁 Looking for .env at: {ENV_PATH}")