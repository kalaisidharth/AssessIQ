from motor.motor_asyncio import AsyncIOMotorClient
from core.config import settings

class _DB:
    client: AsyncIOMotorClient = None
    db = None

_state = _DB()

async def connect_db():
    _state.client = AsyncIOMotorClient(settings.MONGODB_URL)
    _state.db = _state.client[settings.DATABASE_NAME]
    # Verify connection
    await _state.client.admin.command("ping")
    print(f"✅ Connected to MongoDB: {settings.DATABASE_NAME}")

async def close_db():
    if _state.client:
        _state.client.close()
        print("MongoDB connection closed")

def get_db():
    if _state.db is None:
        raise RuntimeError("Database not connected. Did the server start correctly?")
    return _state.db
