from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class UserRole(str, Enum):
    admin = "admin"
    user = "user"

class RoundConfig(BaseModel):
    round_number: int
    name: str
    topic: str
    difficulty: str = "medium"  # easy, medium, hard
    num_questions: int = 5
    min_score_percent: int = 60  # Minimum % to pass this round
    time_limit_minutes: int = 15

class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]

class AssessmentConfig(BaseModel):
    title: str
    description: str = ""
    rounds: List[RoundConfig]
    assigned_to: List[str] = []  # user IDs
    allow_retake: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

class AssessmentAssign(BaseModel):
    assessment_id: str
    user_ids: List[str]

class QuestionAnswer(BaseModel):
    question_id: str
    question: str
    selected_option: str
    correct_option: str
    is_correct: bool

class RoundResult(BaseModel):
    round_number: int
    round_name: str
    score: int
    total: int
    percent: float
    passed: bool
    time_taken_seconds: int
    answers: List[QuestionAnswer]

class AssessmentSubmission(BaseModel):
    assessment_id: str
    round_number: int
    answers: List[Dict[str, str]]
    time_taken_seconds: int

class MinScoreUpdate(BaseModel):
    round_number: int
    min_score_percent: int

class AdminSetMin(BaseModel):
    assessment_id: str
    rounds_min_scores: Dict[int, int]  # round_number -> min_score_percent
