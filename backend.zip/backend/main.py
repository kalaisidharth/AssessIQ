from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from core.database import connect_db, close_db

app = FastAPI(title="Interview Assessment API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    await connect_db()

@app.on_event("shutdown")
async def shutdown():
    await close_db()

# Import routers AFTER app is created to avoid circular imports
from routers.auth import router as auth_router
from routers.admin import router as admin_router
from routers.user import router as user_router
from routers.assessment import router as assessment_router

app.include_router(auth_router, prefix="/api/auth", tags=["Auth"])
app.include_router(admin_router, prefix="/api/admin", tags=["Admin"])
app.include_router(user_router, prefix="/api/user", tags=["User"])
app.include_router(assessment_router, prefix="/api/assessment", tags=["Assessment"])

@app.get("/")
async def root():
    return {"message": "Interview Assessment API Running"}
